int evaluate(unsigned int guess);
unsigned int guess_the_number(void);
